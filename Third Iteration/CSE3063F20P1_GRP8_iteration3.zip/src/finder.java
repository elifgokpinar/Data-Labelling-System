
import java.util.ArrayList;

public interface finder {

	public abstract int find(ArrayList<User>listOfuser,ArrayList<Label>listlabel,ArrayList<Instancee>listinstance,Long id);
}



import java.util.ArrayList;

public interface finder {

	public abstract int find(ArrayList<LABEL>listlabel,ArrayList<INSTANCE>listinstance,Long id);
}

